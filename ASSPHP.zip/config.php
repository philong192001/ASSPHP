<?php 
	define('HOST', 'localhost');
	define('DATABASE', 'quanlysanpham');
	define('USERNAME', 'root');
	define('PASSWORD', '');
 ?>